<?php

use WHMCS\Module\Addon\Iletimerkezi\HookService;

$hooks = HookService::all();

foreach($hooks as $hook) {
    add_hook($hook['name'], 99, $hook['func']);
}