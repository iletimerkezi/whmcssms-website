<div class="tablebg">
    <table id="sortabletbl1" class="datatable" width="99%">
        <tbody>
            <tr>
                <th>
                    <?php echo $lang->get('template_type_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('template_template_title'); ?>
                </th>
            </tr>
            <?php
            foreach($data['templates'] as $template) {
            ?>
                <tr>
                    <td>
                        <?php echo $lang->get('template_' . $template->hook_type . '_title'); ?>
                    </td>
                    <td>
                        <div class="alert alert-warning" role="alert">
                            <?php echo $lang->get($template->hook_name.'_desc'); ?>
                            <br />
                            <br />
                            <b>
                                <?php echo $lang->get('template_hook_title'); ?>
                            </b>
                            <?php echo $template->hook_name; ?>
                            <br />
                            <?php
                            if($template->variables != '') {
                            ?>
                                <b>
                                    <?php echo $lang->get('template_available_variables_title'); ?>
                                </b>
                                <?php echo $template->variables; ?>
                            <?php
                            }
                            ?>
                            <br />
                            <b>
                                <?php echo $lang->get('template_sample_message_title'); ?>
                            </b>
                            <?php
                            echo $lang->get($template->hook_name.'_default');
                            ?>
                        </div>

                        <div
                            id="<?php echo $template->hook_name; ?>-error-box"
                            class="alert alert-danger hidden"
                            role="alert">
                            <?php echo $lang->get('template_saved_error'); ?>
                        </div>

                        <div
                            id="<?php echo $template->hook_name; ?>-success-box"
                            class="alert alert-success hidden"
                            role="alert">
                            <?php echo $lang->get('template_saved_success'); ?>
                        </div>

                        <form class="form-horizontal">
                            <div class="form-group">
                                <label
                                    for="<?php echo $template->hook_name; ?>-template"
                                    class="col-sm-2 control-label">
                                    <?php echo $lang->get('template_message_title'); ?>
                                </label>
                                <div class="col-sm-10">
                                    <textarea
                                        id="<?php echo $template->hook_name; ?>-template"
                                        class="form-control w-75"
                                        rows="3"><?php echo $template->template; ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <div class="checkbox">
                                        <label>
                                            <input
                                                id="<?php echo $template->hook_name; ?>-state"
                                                <?php echo $template->active == 'Y' ? 'checked' : ''; ?>
                                                type="checkbox"> <?php echo $lang->get('template_activate_disabled_title'); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <button
                                        onclick="saveTemplate('<?php echo $template->hook_name; ?>');"
                                        type="button"
                                        class="btn btn-primary">
                                        <?php echo $lang->get('save'); ?>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>

<script>
function saveTemplate(hook_name) {

    $('#' + hook_name + '-success-box').addClass('hidden');
    $('#' + hook_name + '-error-box').addClass('hidden');

    $.post("<?php echo $base; ?>&route=templates_save", {
        hook_name: hook_name,
        template : $('#' + hook_name + '-template').val(),
        state    : $('#' + hook_name + '-state').is(':checked') ? true : false
    })
    .done(function( data ) {
        $('#' + hook_name + '-success-box').removeClass('hidden');
    })
    .fail(function() {
        $('#' + hook_name + '-error-box').removeClass('hidden');
    });

    return false;
}
</script>