<div class="admin-tabs-v2">
    <ul class="nav nav-tabs admin-tabs" role="tablist">
        <li
            class="settings <?php echo $data['active'] === 'settings' ? 'active' : ''; ?>"
            role="presentation">
            <a href="<?php echo $base . '&route=settings'; ?>" role="tab">
                <?php echo $lang->get('tab_settings'); ?>
            </a>
        </li>
        <li
            class="templates <?php echo $data['active'] === 'templates' ? 'active' : ''; ?>"
            role="presentation">
            <a href="<?php echo $base . '&route=templates'; ?>">
                <?php echo $lang->get('tab_templates'); ?>
            </a>
        </li>
        <li
            class="reports <?php echo $data['active'] === 'reports' ? 'active' : ''; ?>"
            role="presentation">
            <a href="<?php echo $base . '&route=reports&page=1'; ?>" role="tab">
                <?php echo $lang->get('tab_reports'); ?>
            </a>
        </li>
            <li
                class="otp <?php echo $data['active'] === 'verify' ? 'active' : ''; ?>"
                role="presentation">
            <a href="<?php echo $base . '&route=verify&page=1'; ?>" role="tab">
                <?php echo $lang->get('tab_verify'); ?>
            </a>
        </li>
    </ul>

    <div class="tab-content">
        <div
            class="tab-pane <?php echo $data['active'] === 'settings' ? 'active' : ''; ?>"
            id="settings">
            <?php echo $data['settings_panel']; ?>
        </div>
        <div
            class="tab-pane <?php echo $data['active'] === 'templates' ? 'active' : ''; ?>"
            id="templates">
            <?php echo $data['templates_panel']; ?>
        </div>
        <div
            class="tab-pane <?php echo $data['active'] === 'reports' ? 'active' : ''; ?>"
            id="reports">
            <?php echo $data['reports_panel']; ?>
        </div>
        <div
            class="tab-pane <?php echo $data['active'] === 'verify' ? 'active' : ''; ?>"
            id="otp">
            <?php echo $data['verify_panel']; ?>
        </div>
    </div>
</div>