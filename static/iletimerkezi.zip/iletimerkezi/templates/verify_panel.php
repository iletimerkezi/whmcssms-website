<div class="search-bar" id="search-bar">
    <div class="simple">
        <div class="search-icon">
            <div class="icon-wrapper">
                <i class="fas fa-search"></i>
            </div>
        </div>
        <div class="search-fields">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-3 col-lg-2">
                    <div class="form-group">
                        <label for="inputName">
                            <?php echo $lang->get('verify_user_id_title'); ?>
                        </label>
                        <input type="text" name="name" id="inputName" class="form-control" value="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-3 col-lg-2">
                    <div class="form-group">
                        <label for="inputName">
                            <?php echo $lang->get('verify_gsm_title'); ?>
                        </label>
                        <input type="text" name="name" id="inputName" class="form-control" value="">
                    </div>
                </div>
                <div class="col-xs-6 col-sm-2 col-md-1">
                    <label class="clear-search hidden-xs">&nbsp;</label>
                    <button type="submit" id="btnSearchClients" class="btn btn-primary btn-sm btn-search btn-block">
                        <i class="fas fa-search fa-fw"></i>
                        <span class="hidden-md">
                            <?php echo $lang->get('search'); ?>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<table width="100%" cellspacing="0" cellpadding="3" border="0">
    <tbody>
        <tr>
            <td width="50%" align="left">
                <?php echo $data['count']; ?>
                <?php echo $lang->merge('records_found', [$data['page'], $data['page_size']]); ?>
            </td>
            <td width="50%" align="right">
                <?php echo $lang->get('jump_page'); ?>
                <select id="page" name="page" onchange="go()">
                    <?php
                    for($i = 1; $i <= $data['page_size']; $i++ ) {
                    ?>
                        <option
                            value="<?php echo $i; ?>"
                            <?php echo $data['page'] == $i ? 'selected' : ''; ?>>
                            <?php echo $i; ?>
                        </option>
                    <?php
                    }
                    ?>
                </select>
            </td>
        </tr>
    </tbody>
</table>

<div class="tablebg">
    <table id="sortabletbl1" class="datatable" width="100%" cellspacing="1" cellpadding="3" border="0">
        <tbody>
            <tr>
                <th>
                    <?php echo $lang->get('verify_id_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('verify_user_id_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('verify_pin_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('verify_gsm_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('verify_status_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('verify_expired_at_title'); ?>
                </th>
            </tr>
            <?php
            foreach($data['verifies'] as $verify) {
            ?>
                <tr>
                    <td><?php echo $verify->id; ?></td>
                    <td><?php echo $verify->client_id; ?></td>
                    <td><?php echo $verify->pin; ?></td>
                    <td><?php echo $verify->gsm; ?></td>
                    <td>
                        <?php
                        if(is_null($verify->verify_at)) {
                        ?>
                            <span class="label label-warning">
                                <?php echo $lang->get('verify_status_waiting_title'); ?>
                            </span>
                        <?php
                        } else {
                        ?>
                            <span class="label label-success">
                                <?php echo $lang->get('verify_status_verified_title'); ?>
                            </span>
                        <?php
                        }
                        ?>
                    </td>
                    <td><?php echo $verify->expired_at; ?></td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>

<ul class="pager">
    <li class="previous <?php echo $data['page'] == 1 ? 'disabled' : ''; ?>">
        <a
            href="<?php echo $base; ?>&route=verify&page=<?php echo $data['page'] - 1; ?>">
            <?php echo $lang->get('previous_page'); ?>
        </a>
    </li>
    <li class="next <?php echo $data['page'] == $data['page_size'] ? 'disabled' : ''; ?>">
        <a
            href="<?php echo $base; ?>&route=verify&page=<?php echo $data['page'] + 1; ?>">
            <?php echo $lang->get('next_page'); ?>
        </a>
    </li>
</ul>

<script>
function go() {
    window.location = '<?php echo $base; ?>&route=verify&page=' + $('#page').val();
}
</script>