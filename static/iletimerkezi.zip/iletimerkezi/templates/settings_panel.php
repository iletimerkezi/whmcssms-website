<?php
if(! $data['balance']['success']) {
?>
    <div id="api-error-box" class="alert alert-danger" role="alert">
        <?php echo $lang->get('settings_api_auth_error'); ?>
        (<?php echo $data['balance']['message']; ?>)
    </div>
<?php
}
?>

<div id="error-box" class="alert alert-danger hidden" role="alert">
    <?php echo $lang->get('settings_save_error'); ?>
</div>

<div  id="success-box" class="alert alert-success hidden" role="alert">
    <?php echo $lang->get('settings_save_success'); ?>
</div>

<form class="form-horizontal">
    <div class="form-group">
        <label for="balance" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_balance_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_balance_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                disabled
                type="text"
                class="form-control input-300"
                id="balance"
                name="balance"
                value="<?php echo $data['balance']['success'] ? $data['balance']['balance'] : ''; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="api_key" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_api_key_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_api_key_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="api_key"
                name="api_key"
                value="<?php echo $data['settings']['api_key']; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="api_hash" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_api_hash_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_api_hash_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="api_hash"
                name="api_hash"
                value="<?php echo $data['settings']['api_hash']; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="sender" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_sender_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_sender_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="sender"
                name="sender"
                value="<?php echo $data['settings']['sender']; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="admins" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_admin_phones_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_admin_phones_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="admins"
                name="admins"
                value="<?php echo $data['settings']['admins']; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="canceled_domain_after" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_canceled_domain_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_canceled_domain_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="canceled_domain_after"
                name="canceled_domain_after"
                value="<?php echo $data['settings']['canceled_domain_after']; ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="canceled_domain_after" class="col-md-4 col-sm-6 control-label">
            <?php echo $lang->get('settings_webhook_title'); ?>
            <br>
            <small>
                <?php echo $lang->get('settings_webhook_desc'); ?>
            </small>
        </label>
        <div class="col-md-8 col-sm-6">
            <input
                type="text"
                class="form-control input-300"
                id="canceled_domain_after"
                name="canceled_domain_after"
                onClick="this.select();"
                value="<?php echo $data['webhook']; ?>">
        </div>
    </div>
</form>

<hr />

<div class="text-center">
    <button
        id="settingSaveBtn"
        type="submit"
        onclick="saveSettings();"
        class="btn btn-primary">
        <?php echo $lang->get('save'); ?>
    </button>
</div>

<script>
function saveSettings() {

    $('#success-box').addClass('hidden');
    $('#error-box').addClass('hidden');
    $('#api-error-box').addClass('hidden');
    $('#settingSaveBtn').prop('disabled', true);

    $.post("<?php echo $base; ?>&route=settings_save", {
        api_key: $('#api_key').val(),
        api_hash: $('#api_hash').val(),
        sender: $('#sender').val(),
        admins: $('#admins').val(),
        canceled_domain_after: $('#canceled_domain_after').val()
    })
    .done(function( data ) {
        $('#success-box').removeClass('hidden');
        $('#settingSaveBtn').prop('disabled', false);
    })
    .fail(function() {
        $('#error-box').removeClass('hidden');
        $('#settingSaveBtn').prop('disabled', false);
    });
}
</script>