<?php

use Exception;
use WHMCS\Module\Addon\Iletimerkezi\{
    TemplateService,
    RequestService,
    LanguageService,
    RouterService,
    SetupService
};

function iletimerkezi_config()
{
    return [
        "name"        => "IletiMerkezi SMS",
        "description" => "IletiMerkezi SMS Addon",
        "version"     => "1.00",
        "author"      => "IletiMerkezi",
        "language"    => SetupService::defaultLanguage()
    ];
}

function iletimerkezi_activate()
{
    try {

        SetupService::uninstall();
        SetupService::install();
        SetupService::installJson();

        return [
            'status'      => 'success',
            'description' => 'IletiMerkezi module is activated.',
        ];

    } catch (Exception $e) {
        return [
            'status'      => "error",
            'description' => 'Unable to create database tables: ' . $e->getMessage(),
        ];
    }
}

function iletimerkezi_deactivate()
{
    try {

        SetupService::uninstall();

        return [
            'status'      => 'success',
            'description' => 'IletiMerkezi module is deactivated.',
        ];
    } catch (Exception $e) {
        return [
            "status"      => "error",
            "description" => "Unable to drop IletiMerkezi: {$e->getMessage()}",
        ];
    }
}

function iletimerkezi_output($vars)
{
    $lang     = new LanguageService($vars['_lang']);
    $request  = new RequestService();
    $template = new TemplateService($lang);
    $router   = new RouterService($request, $template);

    echo $router->route('admin');
}

function iletimerkezi_clientarea($vars)
{
    $lang     = new LanguageService($vars['_lang']);
    $request  = new RequestService();
    $template = new TemplateService($lang);
    $router   = new RouterService($request, $template);

    return $router->route('client');
}