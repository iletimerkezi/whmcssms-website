<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Models;

use WHMCS\Database\Capsule;

class ReportModel
{
    public static function table()
    {
        return Capsule::table('iletimerkezi_sms_reports');
    }

    public static function updateState($packet_id, $state)
    {
        self::table()
            ->where('gw_id', $packet_id)
            ->update(['state' => $state]);
    }

    public static function createFromResponse($response)
    {
        self::table()
            ->insert([
                'gw_id'      => $response['success'] ? $response['id'] : NULL,
                'to'         => $response['to'],
                'body'       => $response['body'],
                'sender'     => $response['sender'],
                'state'      => $response['state'],
                'fail_desc'  => $response['success'] ? NULL : $response['message'],
                'created_at' => Capsule::raw('NOW()')
            ]);
    }

    public static function createFromResponseCollection($collection)
    {
        foreach($collection as $response) {
            self::table()
                ->insert([
                    'gw_id'      => $response['success'] ? $response['id'] : NULL,
                    'to'         => $response['to'],
                    'body'       => $response['body'],
                    'sender'     => $response['sender'],
                    'state'      => $response['state'],
                    'fail_desc'  => $response['success'] ? NULL : $response['message'],
                    'created_at' => Capsule::raw('NOW()')
                ]);
        }
    }

    public static function filter($request)
    {
        $count   = self::table()->count();
        $reports = self::table()
            ->orderByDesc('id')
            ->forPage($request->get('page', 1), 15)
            ->get();

        return [
            'count' => $count,
            'data'  => $reports
        ];
    }
}