<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Models;

use WHMCS\Database\Capsule;

class SettingModel
{
    protected $attr = [
        'api_key'  => '',
        'api_hash' => '',
        'sender'   => '',
        'admins'   => '',
        'canceled_domain_after' => ''
    ];

    public function get()
    {
        $map = $this->attr;

        foreach(Capsule::table('iletimerkezi_settings')->get() as $item) {
            $map[$item->settings_key] = $item->settings_value;
        }

        return $map;
    }

    public function save($request)
    {
        foreach($this->attr as $key => $map) {
            Capsule::table('iletimerkezi_settings')
                ->updateOrInsert(['settings_key' => $key], [
                    'settings_value' => $request->get($key, '')
                ]);
        }
    }

    public static function canceledDomainAfter()
    {
        $day = Capsule::table('iletimerkezi_settings')
            ->where('settings_key', 'canceled_domain_after')
            ->first();

        return (int) $day->settings_value;
    }
}