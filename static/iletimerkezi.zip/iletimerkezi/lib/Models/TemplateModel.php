<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Models;

use WHMCS\Database\Capsule;

class TemplateModel
{
    public static function table()
    {
        return Capsule::table('iletimerkezi_sms_templates');
    }

    public static function get()
    {
        return self::table()->get();
    }

    public static function update($hook, $template, $state)
    {
        self::table()
            ->updateOrInsert(['hook_name' =>  $hook], [
                'template' => $template,
                'active'   => $state ? 'Y' : 'N'
            ]);
    }

    public static function getByHookName($name)
    {
        return self::table()
            ->where('hook_name', $name)
            ->first();
    }
}