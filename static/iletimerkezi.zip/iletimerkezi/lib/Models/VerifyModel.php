<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Models;

use WHMCS\Database\Capsule;

class VerifyModel
{
    public static function table()
    {
        return Capsule::table('iletimerkezi_verify');
    }

    public static function isVerified($client_id)
    {
        return self::table()
            ->where('client_id', $client_id)
            ->whereNotNull('verify_at')
            ->exists();
    }

    public static function isExpired($id)
    {
        return self::table()
            ->where('id', $id)
            ->where('expired_at', '<', Capsule::raw('NOW()'))
            ->exists();
    }

    public static function getByClientId($client_id)
    {
        return self::table()
            ->where('client_id', $client_id)
            ->first();
    }

    public static function verify($id, $pin)
    {
        $verify = self::table()
            ->where('id', $id)
            ->first();

        if(is_null($verify)) {
            return false;
        }

        if((int) $verify->pin === (int) $pin) {
            return $verify;
        }

        return false;
    }

    public static function setVerified($id)
    {
        self::table()
            ->where('id', $id)
            ->update(['verify_at' => Capsule::raw('NOW()')]);
    }

    public static function setPin($id)
    {
        if(! self::isExpired($id)) {
            return null;
        }

        self::table()
            ->where('id', $id)
            ->update([
                'pin'        => rand(100000, 999999),
                'expired_at' => Capsule::raw('(NOW() + INTERVAL 5 MINUTE)')
            ]);

        return self::table()->where('id', $id)->first();
    }

    public static function newPin($client_id, $gsm)
    {
        self::table()
            ->updateOrInsert(['client_id' => $client_id], [
                'pin'        => rand(100000, 999999),
                'gsm'        => $gsm,
                'expired_at' => Capsule::raw('(NOW() + INTERVAL 5 MINUTE)')
            ]);

        return self::table()->where('client_id', $client_id)->first();
    }

    public static function delete($id)
    {
        self::table()
            ->where('id', $id)
            ->delete();
    }

    public static function filter($request)
    {
        $count = self::table()
            ->when(!is_null($request->get('user_id', null)), function($query) use ($request) {
                $query->where('user_id', $request->get('user_id'));
            })
            ->when(!is_null($request->get('gsm', null)), function($query) use ($request) {
                $query->where('gsm', $request->get('gsm'));
            })
            ->count();

        $verifies = self::table()
            ->when(!is_null($request->get('user_id', null)), function($query) use ($request) {
                $query->where('user_id', $request->get('user_id'));
            })
            ->when(!is_null($request->get('gsm', null)), function($query) use ($request) {
                $query->where('gsm', $request->get('gsm'));
            })
            ->orderByDesc('id')
            ->forPage($request->get('page', 1), 15)
            ->get();

        return [
            'count' => $count,
            'data'  => $verifies
        ];
    }
}