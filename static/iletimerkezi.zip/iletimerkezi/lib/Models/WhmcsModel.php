<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Models;

use WHMCS\Database\Capsule;

class WhmcsModel
{
    public static function client($client_id)
    {
        return Capsule::table('tblclients')
                ->where('id', $client_id)
                ->first();
    }

    public static function invoice($invoice_id)
    {
        return Capsule::table('tblinvoices')
            ->where('id', $invoice_id)
            ->first();
    }

    public static function ticket($ticket_id)
    {
        return Capsule::table('tbltickets')
            ->where('id', $ticket_id)
            ->first();
    }

    public static function order($order_id)
    {
        return Capsule::table('tblorders')
            ->where('id', $order_id)
            ->first();
    }

    public static function expireDomainsAfterXDay($day)
    {
        return Capsule::table('tbldomains')
            ->where('status', 'Active')
            ->whereDate(
                Capsule::raw('DATE_SUB(expirydate, INTERVAL ' . $day . ' DAY)'),
                Capsule::raw('DATE(NOW())')
            )
            ->get();
    }
}