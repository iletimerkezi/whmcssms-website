<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

use WHMCS\Module\Addon\Iletimerkezi\Controllers\{
    SettingsController,
    TemplatesController,
    ReportsController,
    WebhookController,
    VerifyController,
    EppController
};

class RouterService
{
    public $request;
    public $template;

    public function __construct($request, $template)
    {
        $this->request  = $request;
        $this->template = $template;
    }

    public function route($section)
    {
        if($section === 'client') {
            return $this->routeForClient();
        }

        return $this->routeForAdmin();
    }

    public function routeForAdmin()
    {
        $route = $this->request->get('route', 'settings');

        $settingsController  = new SettingsController($this->template);
        $templatesController = new TemplatesController($this->template);
        $reportController    = new ReportsController($this->template);
        $verifyController    = new VerifyController($this->template);

        $map = [
            'settings'       => [$settingsController, 'page'],
            'settings_save'  => [$settingsController, 'save'],
            'templates'      => [$templatesController, 'page'],
            'templates_save' => [$templatesController, 'save'],
            'reports'        => [$reportController, 'page'],
            'verify'         => [$verifyController, 'page']
        ];

        return call_user_func_array($map[$route], [$this->request]);
    }

    public function routeForClient()
    {
        $route = $this->request->get('route', 'verifyForm');

        $verifyController  = new VerifyController($this->template);
        $webhookController = new WebhookController($this->template);
        $eppController     = new EppController($this->template);

        $map = [
            'verifyForm'  => [$verifyController, 'verifyForm'],
            'verifyPin'   => [$verifyController, 'verifyPin'],
            'sendPin'     => [$verifyController, 'sendPin'],
            'isPinExpire' => [$verifyController, 'isPinExpire'],
            'webhook'     => [$webhookController, 'process'],
            'eppcode'     => [$eppController, 'success']
        ];

        return call_user_func_array($map[$route], [$this->request]);
    }
}