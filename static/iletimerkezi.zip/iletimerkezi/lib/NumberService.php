<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

class NumberService
{
    public static function format($number)
    {
        $number = preg_replace('/\D/', '', $number);

        return '+' . $number;
    }
}