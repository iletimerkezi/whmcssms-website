<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

class TemplateService
{
    public $lang;

    public function __construct($lang)
    {
        $this->lang = $lang;
    }

    public function adminPage($data = [])
    {
        $admin = array_merge([
            'active'          => 'settings',
            'settings_panel'  => '',
            'templates_panel' => '',
            'reports_panel'   => '',
            'otp_panel'       => ''
            ], $data
        );

        return $this->render('admin_layout', $admin);
    }

    public function render($file, $data = [])
    {
        $path = dirname(__FILE__).'/../templates/' . $file . '.php';

        if (! file_exists($path)) {
            exit('Error: Could not load template ' . $path);
        }

        extract([
            'base' => 'addonmodules.php?module=iletimerkezi',
            'data' => $data,
            'lang' => $this->lang
        ]);

        ob_start();
        include($path);
        $html = ob_get_contents();
        ob_end_clean();

        return $html;
    }
}