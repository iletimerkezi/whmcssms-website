<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class ReportsController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function page($request)
    {
        $report = ReportModel::filter($request);
        $size   = (int) ceil($report['count'] / 15) === 0 ? 1 : ceil($report['count'] / 15);

        return $this->template->adminPage([
            'active'        => 'reports',
            'reports_panel' => $this->template->render('reports_panel', [
                'count'     => $report['count'],
                'page_size' => $size,
                'page'      => $request->get('page', 1),
                'reports'   => $report['data']
            ])
        ]);
    }
}