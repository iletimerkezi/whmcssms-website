<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

use WHMCS\Module\Addon\Iletimerkezi\SMSService;
use WHMCS\Module\Addon\Iletimerkezi\Models\SettingModel;

class SettingsController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function page($request)
    {
        $settings = (new SettingModel())->get();
        $balance  = (new SMSService($settings))->balance();
        $uri      = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'];

        return $this->template->adminPage([
            'active'         => 'settings',
            'settings_panel' => $this->template->render('settings_panel', [
                'balance'  => $balance,
                'settings' => $settings,
                'webhook'  => $uri . '/index.php?m=iletimerkezi&route=webhook'
            ])
        ]);
    }

    public function save($request)
    {
        (new SettingModel())->save($request);

        return json_encode(['success' => true]);
    }
}