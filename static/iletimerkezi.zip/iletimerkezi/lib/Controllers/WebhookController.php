<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class WebhookController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function process($request)
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json);


        $map = [
            'accepted'    => 'waiting',
            'delivered'   => 'success',
            'undelivered' => 'fail',
        ];

        ReportModel::updateState(
            $data->report->packet_id,
            $map[$data->report->status]
        );

        die('OK');
    }
}