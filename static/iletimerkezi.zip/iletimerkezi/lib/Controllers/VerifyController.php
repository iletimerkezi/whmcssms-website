<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

use WHMCS\Module\Addon\Iletimerkezi\SMSService;
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    VerifyModel,
    TemplateModel,
    WhmcsModel
};

class VerifyController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function page($request)
    {
        $verifies = VerifyModel::filter($request);
        $size     = (int) ceil($verifies['count'] / 15) === 0 ? 1 : ceil($verifies['count'] / 15);

        return $this->template->adminPage([
            'active' => 'verify',
            'verify_panel' => $this->template->render('verify_panel', [
                'count'     => $verifies['count'],
                'page_size' => $size,
                'page'      => $request->get('page', 1),
                'verifies'  => $verifies['data']
            ])
        ]);
    }

    public function verifyForm($request)
    {
        return [
            'pagetitle'  => $this->template->lang->get('vp_bc_title'),
            'breadcrumb' => [
                'index.php?m=iletimerkezi&route=verifyForm' => $this->template->lang->get('vp_bc_title'),
            ],
            'templatefile' => 'verify_form',
            'requirelogin' => false,
            'forcessl'     => false,
            'vars'         => [
                'ref'  => $request->get('ref', null),
                'gsm'  => $request->get('gsm', null),
                'lang' => $this->template->lang
            ]
        ];
    }

    public function verifyPin($request)
    {
        if(VerifyModel::isExpired($request->get('ref', ''))) {
            $this->responseApi([
                'success' => false,
                'message' => $this->template->lang->get('vp_expired_error'),
                'expired' => true
            ]);
        }

        $verify = VerifyModel::verify($request->get('ref'), $request->get('pin'));

        if(! $verify) {
            $this->responseApi([
                'success' => false,
                'message' => $this->template->lang->get('vp_error'),
                'expired' => false
            ]);
        }

        VerifyModel::setVerified($verify->id);

        $this->responseApi([
            'success'  => true,
            'redirect' => $this->userRedirectLink($verify->client_id)
        ]);
    }

    public function sendPin($request)
    {
        $verify = VerifyModel::setPin($request->get('ref'));

        if(is_null($verify)) {
            $this->responseApi([
                'success' => false,
                'message' => $this->template->lang->get('vp_already_verified_error')
            ]);
        }

        (new SMSService())->send($verify->gsm, $this->message($verify));

        $this->responseApi(['success' => true]);
    }

    public function isPinExpire($request)
    {
        if(VerifyModel::isExpired($request->get('ref', ''))) {
            $this->responseApi(['success' => true]);
        }

        $this->responseApi(['success' => false]);
    }

    private function message($verify)
    {
        $template = TemplateModel::getByHookName('SendUserVerifyCode');
        $client   = WhmcsModel::client($verify->client_id);
        $search   = explode(',', $template->variables);

        return str_replace(
            $search + ['{code}'],
            [$client->firstname, $client->lastname, $verify->pin],
            $template->template
        );
    }

    private function responseApi($response =[])
    {
        die(json_encode($response));
    }

    private function userRedirectLink($client_id)
    {
        $result = localAPI('CreateSsoToken', [
            'client_id'   => $client_id,
            'destination' => ''
        ]);

        return $result['redirect_url'];
    }
}