<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

class EppController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function success($request)
    {
        return [
            'pagetitle'  => $this->template->lang->get('vp_bc_title'),
            'breadcrumb' => [
                'index.php?m=iletimerkezi&route=eppcode' => $this->template->lang->get('vp_bc_title'),
            ],
            'templatefile' => 'eppcode_sent',
            'requirelogin' => false,
            'forcessl'     => false,
            'vars'         => [
                'lang' => $this->template->lang
            ]
        ];
    }
}