<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

use WHMCS\Module\Addon\Iletimerkezi\ResponseService;
use WHMCS\Module\Addon\Iletimerkezi\Models\SettingModel;

class SMSService
{
    public $base     = 'https://api.iletimerkezi.com/v1/';
    public $settings = [];

    public function __construct()
    {
        $this->settings = (new SettingModel())->get();
    }

    public function send($recipent, $body)
    {
        $data = '
        <request>
            <authentication>
                <key>' . $this->settings['api_key'] . '</key>
                <hash>'. $this->settings['api_hash'] . '</hash>
            </authentication>
            <order>
                <sender>' . $this->settings['sender'] . '</sender>
                <sendDateTime></sendDateTime>
                <iys>0</iys>
                <iysList>BIREYSEL</iysList>
                <message>
                    <text><![CDATA['.$body.']]></text>
                    <receipents>
                        <number>'.$recipent.'</number>
                    </receipents>
                </message>
            </order>
        </request>';

        $response = $this->request('send-sms', $data);

        $result   = ResponseService::sendSMS($response);

        return $result + [
            'sender' => $this->settings['sender'],
            'body'   => $body,
            'to'     => $recipent,
            'state'  => 'waiting'
        ];
    }

    public function sendAdmins($body)
    {
        $admins = explode(',', $this->settings['admins']);

        $result = [];
        foreach($admins as $admin) {
            $result[] = $this->send($admin, $body);
        }

        return $result;
    }

    public function balance()
    {
        $data = '
            <request>
                <authentication>
                    <key>' . $this->settings['api_key'] . '</key>
                    <hash>' . $this->settings['api_hash'] . '</hash>
                </authentication>
            </request>
        ';

        $response = $this->request('get-balance', $data);

        return ResponseService::balance($response);
    }

    private function request($type, $data)
    {
        $ch = curl_init();
    	curl_setopt($ch, CURLOPT_URL, $this->base . $type);
    	curl_setopt($ch, CURLOPT_POST, 1);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,1);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    	curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: text/xml']);
    	curl_setopt($ch, CURLOPT_HEADER, 0);
    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    	curl_setopt($ch, CURLOPT_TIMEOUT, 120);

    	$result = curl_exec($ch);

    	return $result;
    }
}