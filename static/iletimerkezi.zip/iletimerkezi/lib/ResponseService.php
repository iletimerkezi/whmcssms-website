<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

class ResponseService
{
    public static function balance($response)
    {
        $result = simplexml_load_string($response);

        if((int) $result->status->code === 200) {
            return [
                'success' => true,
                'message' => (string) $result->status->message,
                'balance' => (int) $result->balance->sms,
            ];
        }

        return [
            'success' => false,
            'message' => (string) $result->status->message,
            'balance' => 0,
        ];
    }

    public static function sendSMS($response)
    {
        $result = simplexml_load_string($response);

        if((int) $result->status->code === 200) {
            return [
                'success' => true,
                'message' => (string) $result->status->message,
                'id'      => (int) $result->order->id
            ];
        }

        return [
            'success' => false,
            'message' => (string) $result->status->message
        ];
    }
}