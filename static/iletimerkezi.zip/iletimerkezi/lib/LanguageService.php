<?php

namespace WHMCS\Module\Addon\Iletimerkezi;


class LanguageService
{
    protected $map;

    public function __construct($lang)
    {
        $this->map = $lang;
    }

    public function get($key, $default = '')
    {
        return isset($this->map[$key]) ? $this->map[$key] : $default;
    }

    public function merge($key, $variables = [])
    {
        $sentence = isset($this->map[$key]) ? $this->map[$key] : '';

        return vsprintf($sentence, $variables);
    }
}