<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

use WHMCS\Database\Capsule;

class SetupService
{
    public static function install()
    {
        Capsule::schema()
            ->create('iletimerkezi_settings', function ($table) {
                $table->bigIncrements('id');
                $table->string('settings_key');
                $table->string('settings_value');
            });

        Capsule::schema()
            ->create('iletimerkezi_verify', function ($table) {
                $table->bigIncrements('id');
                $table->bigInteger('client_id');
                $table->string('pin');
                $table->string('gsm');
                $table->timestamp('verify_at')->nullable();
                $table->timestamp('expired_at');
            });

        Capsule::schema()
            ->create('iletimerkezi_sms_templates', function ($table) {
                $table->bigIncrements('id');
                $table->string('hook_name');
                $table->enum('hook_type', ['client', 'admin', 'general']);
                $table->string('template', 1500);
                $table->string('variables', 1500);
                $table->enum('active', ['Y', 'N']);
            });

        Capsule::schema()
            ->create('iletimerkezi_sms_reports', function ($table) {
                $table->bigIncrements('id');
                $table->unsignedBigInteger('gw_id')->nullable();
                $table->string('to', 20);
                $table->string('body', 1500);
                $table->string('sender')->nullable();
                $table->enum('state', ['success', 'fail', 'waiting']);
                $table->string('fail_desc')->nullable();
                $table->timestamp('created_at');
            });
    }

    public static function uninstall()
    {
        Capsule::schema()->dropIfExists('iletimerkezi_settings');
        Capsule::schema()->dropIfExists('iletimerkezi_verify');
        Capsule::schema()->dropIfExists('iletimerkezi_sms_templates');
        Capsule::schema()->dropIfExists('iletimerkezi_sms_reports');
    }

    public static function installJson()
    {
        $lang  = self::defaultLanguage();
        $path  = dirname(__FILE__).'/../setup.json';
        $json  = file_get_contents($path);
        $datas = json_decode($json, TRUE);

        foreach($datas as $data) {

            Capsule::table('iletimerkezi_sms_templates')
                ->insert([
                    'hook_name' => $data['hook_name'],
                    'hook_type' => $data['hook_type'],
                    'template'  => $data['template_' . $lang],
                    'variables' => $data['variables'],
                    'active'    => 'N'
                ]);
        }
    }

    public static function defaultLanguage()
    {
        $lang = Capsule::table('tblconfiguration')
            ->where('setting', 'Language')
            ->first();

        if(is_null($lang)) {
            $default_lang = 'english';
        } else {
            $default_lang = $lang->value;
        }

        return $default_lang;
    }
}