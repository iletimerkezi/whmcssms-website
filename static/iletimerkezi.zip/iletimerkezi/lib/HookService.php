<?php

namespace WHMCS\Module\Addon\Iletimerkezi;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\{
    SendUserVerifyCode,
    SendDomainEPPCode,
    IsClientPhoneChanged,
    HostingModuleCreated,
    AdminLogged,
    UserLoggedForAdmin,
    InvoicePaymentReminder,
    InvoiceCreated,
    AfterRegistrarDomainRenewalFailedForAdmin,
    AfterModuleSuspend,
    AfterRegistrarRegistrationFailed,
    TicketOpenForAdmin,
    AfterRegistrarDomainRenewal,
    AfterRegistrarDomainRegistrationForAdmin,
    TicketRepliedByAdmin,
    AfterModuleUnsuspend,
    DomainRenewalNotice,
    TicketClosed,
    InvoicePaymentReminderFirstOverdue,
    InvoicePaymentReminderSecondOverdue,
    InvoicePaymentReminderThirdOverdue,
    ClientRegistered,
    TicketOpenClient,
    TicketClientRepliedForAdmin,
    AfterRegistrarDomainRegistration,
    OrderAccepted,
    AfterRegistrarRegistrationFailedForAdmin,
    InvoicePaid,
    AfterModuleChangePackage,
    AfterRegistrarDomainRenewalForAdmin,
    ClientRegisteredForAdmin
};

class HookService
{
    public static function all()
    {
        return [
            [
                'name'  => 'UserLogin',
                'func'  => function($args) {
                    (new SendUserVerifyCode())->run($args);
                }
            ],
            [
                'name' => 'ClientAreaPageDomainEPPCode',
                'func' => function($args) {
                    (new SendDomainEPPCode())->run($args);
                }
            ],
            [
                'name'  => 'ClientAdd',
                'func'  => function($args) {
                    (new SendUserVerifyCode())->run($args);
                }
            ],
            [
                'name'  => 'ClientEdit',
                'func'  => function($args) {
                    (new IsClientPhoneChanged())->run($args);
                }
            ],
            [
                'name' => 'AfterModuleCreate',
                'func' => function($args) {
                    (new HostingModuleCreated())->run($args);
                }
            ],
            [
                'name' => 'AdminLogin',
                'func' => function($args) {
                    (new AdminLogged())->run($args);
                }
            ],
            [
                'name' => 'UserLogin',
                'func' => function($args) {
                    (new UserLoggedForAdmin())->run($args);
                }
            ],
            [
                'name' => 'InvoicePaymentReminder',
                'func' => function($args) {
                    (new InvoicePaymentReminder())->run($args);
                }
            ],
            [
                'name' => 'InvoiceCreated',
                'func' => function($args) {
                    (new InvoiceCreated())->run($args);
                }
            ],
            [
                'name' => 'InvoiceCreationAdminArea',
                'func' => function($args) {
                    (new InvoiceCreated())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistrationFailed',
                'func' => function($args) {
                    (new AfterRegistrarDomainRenewalFailedForAdmin())->run($args);
                }
            ],
            [
                'name' => 'AfterModuleSuspend',
                'func' => function($args) {
                    (new AfterModuleSuspend())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistrationFailed',
                'func' => function($args) {
                    (new AfterRegistrarRegistrationFailed())->run($args);
                }
            ],
            [
                'name' => 'TicketOpen',
                'func' => function($args) {
                    (new TicketOpenForAdmin())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRenewal',
                'func' => function($args) {
                    (new AfterRegistrarDomainRenewal())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistration',
                'func' => function($args) {
                    (new AfterRegistrarDomainRegistrationForAdmin())->run($args);
                }
            ],
            [
                'name' => 'TicketAdminReply',
                'func' => function($args) {
                    (new TicketRepliedByAdmin())->run($args);
                }
            ],
            [
                'name' => 'AfterModuleUnsuspend',
                'func' => function($args) {
                    (new AfterModuleUnsuspend())->run($args);
                }
            ],
            [
                'name' => 'DailyCronJob',
                'func' => function($args) {
                    (new DomainRenewalNotice())->run($args);
                }
            ],
            [
                'name' => 'TicketClose',
                'func' => function($args) {
                    (new TicketClosed())->run($args);
                }
            ],
            [
                'name' => 'InvoicePaymentReminder',
                'func' => function($args) {
                    (new InvoicePaymentReminderFirstOverdue())->run($args);
                }
            ],
            [
                'name' => 'InvoicePaymentReminder',
                'func' => function($args) {
                    (new InvoicePaymentReminderSecondOverdue())->run($args);
                }
            ],
            [
                'name' => 'InvoicePaymentReminder',
                'func' => function($args) {
                    (new InvoicePaymentReminderThirdOverdue())->run($args);
                }
            ],
            [
                'name' => 'ClientAdd',
                'func' => function($args) {
                    (new ClientRegistered())->run($args);
                }
            ],
            [
                'name' => 'TicketOpen',
                'func' => function($args) {
                    (new TicketOpenClient())->run($args);
                }
            ],
            [
                'name' => 'TicketUserReply',
                'func' => function($args) {
                    (new TicketClientRepliedForAdmin())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistration',
                'func' => function($args) {
                    (new AfterRegistrarDomainRegistration())->run($args);
                }
            ],
            [
                'name' => 'AcceptOrder',
                'func' => function($args) {
                    (new OrderAccepted())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistration',
                'func' => function($args) {
                    (new AfterRegistrarRegistrationFailedForAdmin())->run($args);
                }
            ],
            [
                'name' => 'InvoicePaid',
                'func' => function($args) {
                    (new InvoicePaid())->run($args);
                }
            ],
            [
                'name' => 'AfterModuleChangePackage',
                'func' => function($args) {
                    (new AfterModuleChangePackage())->run($args);
                }
            ],
            [
                'name' => 'AfterRegistrarRegistration',
                'func' => function($args) {
                    (new AfterRegistrarDomainRenewalForAdmin())->run($args);
                }
            ],
            [
                'name' => 'ClientAdd',
                'func' => function($args) {
                    (new ClientRegisteredForAdmin())->run($args);
                }
            ]
        ];
    }
}