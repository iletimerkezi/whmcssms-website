<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class ClientRegistered extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($args['client_id']),
                $this->merge($args)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($args)
    {
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $args['firstname'],
                $args['lastname'],
                $args['email'],
                $args['password']
            ],
            $this->template['template']
        );
    }
}