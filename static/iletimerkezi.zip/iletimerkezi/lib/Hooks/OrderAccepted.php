<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class OrderAccepted extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $order = $this->order($args['orderid']);

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($order->userid),
                $this->merge($order->userid, $order)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($client_id, $order)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $order->ordernum
            ],
            $this->template['template']
        );
    }
}