<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class InvoiceCreated extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        if($args['source'] === 'adminarea' && $args['status'] === 'Draft') {
            return null;
        }

        $invoice = $this->invoice($args['invoiceid']);

        if(is_null($invoice)) {
            return null;
        }

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($invoice->userid),
                $this->merge($invoice)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($invoice)
    {
        $client = $this->client($invoice->userid);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $invoice->duedate,
                $invoice->total,
                $invoice->id
            ],
            $this->template['template']
        );
    }
}