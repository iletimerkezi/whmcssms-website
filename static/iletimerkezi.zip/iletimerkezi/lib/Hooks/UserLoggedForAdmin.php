<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    ReportModel,
    VerifyModel
};

class UserLoggedForAdmin extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $whmcs_user = $args['user'];

        if(! $this->isClientCreated($whmcs_user)) {
            return null;
        }

        $client_id = $this->clientId($whmcs_user);

        if(! VerifyModel::isVerified($client_id)) {
            return null;
        }

        $response = $this->im()
            ->sendAdmins(
                $this->merge($client_id)
            );

        ReportModel::createFromResponseCollection($response);
    }

    private function isClientCreated($user)
    {
        $count = $user->getNumberOfClients();

        return $count === 0 ? false : true;
    }

    private function clientId($user)
    {
        return $user->getClientIds()[0];
    }

    private function merge($client_id)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [$client->firstname, $client->lastname],
            $this->template['template']
        );
    }
}