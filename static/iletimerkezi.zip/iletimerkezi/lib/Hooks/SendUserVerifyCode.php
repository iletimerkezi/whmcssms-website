<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    ReportModel,
    VerifyModel
};

class SendUserVerifyCode extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $client_id = $this->getClientIdByArgs($args);

        if(is_null($client_id)) {
            return null;
        }

        $pin      = $this->createPinCode($client_id);
        $body     = $this->merge($client_id, $pin);
        $response = $this->im()->send($pin->gsm, $body);

        ReportModel::createFromResponse($response);

        session_unset();
        header(
            'Location: index.php?m=iletimerkezi&route=verifyForm'.
            '&ref=' . $pin->id .
            '&gsm='. $pin->gsm
        );
        exit;
    }

    private function getClientIdByArgs($args)
    {
        if(isset($args['client_id'])) {
            return $args['client_id'];
        }

        $whmcs_user = $args['user'];

        if(! $this->isClientCreated($whmcs_user)) {
            return null;
        }

        return $this->clientId($whmcs_user);
    }

    private function merge($client_id, $pin)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search + ['{code}'],
            [$client->firstname, $client->lastname, $pin->pin],
            $this->template['template']
        );
    }

    private function isClientCreated($user)
    {
        $count = $user->getNumberOfClients();

        return $count === 0 ? false : true;
    }

    private function clientId($user)
    {
        return $user->getClientIds()[0];
    }

    private function createPinCode($client_id)
    {
        $gsm = $this->clientPhoneNumber($client_id);

        return VerifyModel::newPin($client_id, $gsm);
    }
}