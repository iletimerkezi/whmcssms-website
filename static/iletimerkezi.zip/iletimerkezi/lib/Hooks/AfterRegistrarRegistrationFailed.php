<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class AfterRegistrarRegistrationFailed extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $params    = $args['params'];
        $client_id = $params['userid'];

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($client_id),
                $this->merge($client_id, $params)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($client_id, $params)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $params['sld'] . '.' . $params['tld']
            ],
            $this->template['template']
        );
    }
}