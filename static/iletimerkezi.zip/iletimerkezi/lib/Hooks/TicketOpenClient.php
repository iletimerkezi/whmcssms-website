<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class TicketOpenClient extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $ticket = $this->ticket($args['ticketid']);

        if(is_null($ticket)) {
            return null;
        }

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($ticket->userid),
                $this->merge($ticket)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($ticket)
    {
        $client = $this->client($ticket->userid);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $ticket->title,
                $ticket->tid
            ],
            $this->template['template']
        );
    }
}