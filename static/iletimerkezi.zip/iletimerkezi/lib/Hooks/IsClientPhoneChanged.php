<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\NumberService;
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    VerifyModel
};

class IsClientPhoneChanged
{
    public function run($args)
    {
        $verify = VerifyModel::getByClientId($args['userid']);

        if(is_null($verify)) {
            return null;
        }

        if(is_null($verify->verify_at)) {
            return null;
        }

        $phone = NumberService::format($args['phonenumber']);

        if($verify->gsm !== $phone) {
            VerifyModel::delete($verify->id);
        }
    }
}