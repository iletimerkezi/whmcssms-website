<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\{
    SMSService,
    NumberService
};
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    WhmcsModel,
    TemplateModel
};

class WhmcsHelper
{
    public $template = false;
    public $run      = false;

    public function __construct()
    {
        $this->template = $this->template(end(explode('\\', get_class($this))));

        if(is_array($this->template)) {
            $this->run = true;
        }
    }

    public function template($name)
    {
        $template = TemplateModel::getByHookName($name);

        if(is_null($template)) {
            return false;
        }

        if($template->active === 'N') {
            return false;
        }

        return [
            'template'  => $template->template,
            'variables' => $template->variables
        ];
    }

    public function client($client_id)
    {
        return WhmcsModel::client($client_id);
    }

    public function invoice($invoice_id)
    {
        return WhmcsModel::invoice($invoice_id);
    }

    public function ticket($ticket_id)
    {
        return WhmcsModel::ticket($ticket_id);
    }

    public function order($order_id)
    {
        return WhmcsModel::order($order_id);
    }

    public function activeDomains($day)
    {
        return WhmcsModel::expireDomainsAfterXDay($day);
    }

    public function clientPhoneNumber($client_id)
    {
        $client = $this->client($client_id);

        if(is_null($client)) {
            return null;
        }

        return NumberService::format($client->phonenumber);
    }

    public function im()
    {
        return new SMSService();
    }
}