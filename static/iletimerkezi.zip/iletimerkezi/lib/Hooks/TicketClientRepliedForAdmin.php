<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class TicketClientRepliedForAdmin extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $ticket = $this->ticket($args['ticketid']);

        if(is_null($ticket)) {
            return null;
        }

        $response = $this->im()
            ->sendAdmins(
                $this->merge($ticket)
            );

        ReportModel::createFromResponseCollection($response);
    }

    private function merge($ticket)
    {
        $client = $this->client($ticket->userid);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $ticket->title,
                $ticket->tid
            ],
            $this->template['template']
        );
    }
}