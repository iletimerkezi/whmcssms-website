<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class InvoicePaymentReminder extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        if ($args['type'] !== "reminder") {
            return null;
        }

        $invoice = $this->invoice($args['invoiceid']);

        if(is_null($invoice)) {
            return null;
        }

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($invoice->user_id),
                $this->merge($invoice->user_id, $invoice->duedate)
            );

        ReportModel::createFromResponse($response);
    }

    private function merge($client_id, $due_date)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [$client->firstname, $client->lastname, $due_date],
            $this->template['template']
        );
    }
}