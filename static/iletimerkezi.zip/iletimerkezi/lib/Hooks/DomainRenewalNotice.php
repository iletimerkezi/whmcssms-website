<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\{
    ReportModel,
    SettingModel
};

class DomainRenewalNotice extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $day = SettingModel::canceledDomainAfter();

        $domains = $this->activeDomains($day);
        if(is_null($domains)) {
            return null;
        }

        foreach($domains as $domain) {

            $response = $this->im()
                ->send(
                    $this->clientPhoneNumber($domain->userid),
                    $this->merge($domain, $day)
                );

            ReportModel::createFromResponse($response);
        }
    }

    private function merge($domain, $day)
    {
        $client = $this->client($domain->userid);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $domain->domain,
                $domain->expirydate,
                $day
            ],
            $this->template['template']
        );
    }
}