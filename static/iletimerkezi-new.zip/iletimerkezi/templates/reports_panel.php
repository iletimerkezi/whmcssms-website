<table width="100%" cellspacing="0" cellpadding="3" border="0">
    <tbody>
        <tr>
            <td width="50%" align="left">
                <?php echo $data['count']; ?>
                <?php echo $lang->merge('records_found', [$data['page'], $data['page_size']]); ?>
            </td>
            <td width="50%" align="right">
                <?php echo $lang->get('jump_page'); ?>
                <select id="page" name="page" onchange="go()">
                    <?php
                    for($i = 1; $i <= $data['page_size']; $i++ ) {
                    ?>
                        <option
                            value="<?php echo $i; ?>"
                            <?php echo $data['page'] == $i ? 'selected' : ''; ?>>
                            <?php echo $i; ?>
                        </option>
                    <?php
                    }
                    ?>
                </select>
            </td>
        </tr>
    </tbody>
</table>

<div class="tablebg">
    <table id="sortabletbl1" class="datatable" width="100%" cellspacing="1" cellpadding="3" border="0">
        <tbody>
            <tr>
                <th>
                    <?php echo $lang->get('reports_id_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('reports_gwid_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('reports_to_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('reports_message_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('reports_status_title'); ?>
                </th>
                <th>
                    <?php echo $lang->get('reports_created_at_title'); ?>
                </th>
            </tr>
            <?php
            foreach($data['reports'] as $report) {
            ?>
                <tr>
                    <td><?php echo $report->id; ?> </td>
                    <td><?php echo $report->gw_id; ?></td>
                    <td><?php echo $report->to; ?></td>
                    <td>
                        <b><?php echo $report->sender; ?></b>
                        <br/>
                        <?php echo $report->body; ?>
                    </td>
                    <td>
                        <?php
                        if($report->state === 'success') {
                        ?>
                            <span class="label label-success">
                                <?php echo $lang->get('reports_status_success_title'); ?>
                            </span>
                        <?php
                        }

                        if($report->state === 'fail') {
                        ?>
                            <span
                                class="label label-danger"
                                title="<?php echo $report->fail_desc; ?>">
                                <?php echo $lang->get('reports_status_failed_title'); ?>
                            </span>
                        <?php
                        }

                        if($report->state === 'waiting') {
                        ?>
                            <span class="label label-warning">
                                <?php echo $lang->get('reports_status_waiting_title'); ?>
                            </span>
                        <?php
                        }
                        ?>
                    </td>
                    <td>
                        <?php echo $report->created_at; ?>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>

<ul class="pager">
    <li class="previous <?php echo $data['page'] == 1 ? 'disabled' : ''; ?>">
        <a
            href="<?php echo $base; ?>&route=reports&page=<?php echo $data['page'] - 1; ?>">
            <?php echo $lang->get('previous_page'); ?>
        </a>
    </li>
    <li class="next <?php echo $data['page'] == $data['page_size'] ? 'disabled' : ''; ?>">
        <a
            href="<?php echo $base; ?>&route=reports&page=<?php echo $data['page'] + 1; ?>">
            <?php echo $lang->get('next_page'); ?>
        </a>
    </li>
</ul>

<script>
function go() {
    window.location = '<?php echo $base; ?>&route=reports&page=' + $('#page').val();
}
</script>