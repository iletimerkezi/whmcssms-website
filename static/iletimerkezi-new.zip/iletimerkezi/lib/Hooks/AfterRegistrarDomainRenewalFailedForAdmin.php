<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class AfterRegistrarDomainRenewalFailedForAdmin extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $response = $this->im()
            ->sendAdmins(
                $this->merge($args['params'])
            );

        ReportModel::createFromResponseCollection($response);
    }

    private function merge($params)
    {
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [$params['sld'].'.'.$params['tld']],
            $this->template['template']
        );
    }
}