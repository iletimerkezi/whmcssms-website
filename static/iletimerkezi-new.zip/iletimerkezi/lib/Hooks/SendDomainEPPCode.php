<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class SendDomainEPPCode extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        if(! $args['loggedin']) {
            return null;
        }

        if(!isset($args['eppcode']) || empty($args['eppcode'])) {
            return null;
        }

        $response = $this->im()
            ->send(
                $this->clientPhoneNumber($args['client']->id),
                $this->merge($args['client'], $args['domain'], $args['eppcode'])
            );

        ReportModel::createFromResponse($response);

        header('Location: index.php?m=iletimerkezi&route=eppcode');
        exit;
    }

    private function merge($client, $domain, $eppcode)
    {
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $domain,
                $eppcode
            ],
            $this->template['template']
        );
    }
}