<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Hooks;

use WHMCS\Module\Addon\Iletimerkezi\Hooks\WhmcsHelper;
use WHMCS\Module\Addon\Iletimerkezi\Models\ReportModel;

class TicketOpenForAdmin extends WhmcsHelper
{
    public function run($args)
    {
        if(! $this->run) {
            return null;
        }

        $client_id = $args['userid'];

        $response = $this->im()
            ->sendAdmins(
                $this->merge($client_id, $args)
            );

        ReportModel::createFromResponseCollection($response);
    }

    private function merge($client_id, $args)
    {
        $client = $this->client($client_id);
        $search = explode(',', $this->template['variables']);

        return str_replace(
            $search,
            [
                $client->firstname,
                $client->lastname,
                $args['subject'],
                $args['ticketmask']
            ],
            $this->template['template']
        );
    }
}