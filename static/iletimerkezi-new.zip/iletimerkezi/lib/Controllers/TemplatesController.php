<?php

namespace WHMCS\Module\Addon\Iletimerkezi\Controllers;

use WHMCS\Module\Addon\Iletimerkezi\Models\TemplateModel;

class TemplatesController
{
    public $template;

    public function __construct($template)
    {
        $this->template = $template;
    }

    public function page($request)
    {
        return $this->template->adminPage([
            'active' => 'templates',
            'templates_panel' => $this->template->render('templates_panel', [
                'templates'   => TemplateModel::get()
            ])
        ]);
    }

    public function save($request)
    {
        $hook = $request->get('hook_name', null);

        if(is_null($hook)) {
            return json_encode(['success' => false]);
        }

        TemplateModel::update(
            $hook,
            $request->get('template', ''),
            $request->get('state', false)
        );

        return json_encode(['success' => true]);
    }
}